<?php
// Le Singleton

function counter() {
    static $counter;
    $counter++;
    return $counter;
}

echo counter();
echo counter();
echo counter();


class Test
{
    public static $counter = 0;

    static public function counter()
    {
        self::$counter++;
        return self::$counter;
    }
}

echo Test::counter();

class Math
{
    static public function doubleNumber($number)
    {
        return 2*$number;
    }
}

//$math = new Math();
//$math->doubleNumber(8);

echo Math::doubleNumber(5);


<?php // DesignPattern/Singleton/index.php

require_once 'Singleton.php';
require_once 'Connection.php';

$math  = Math::getInstance();
echo '<br>';

$dsn   = 'mysql:host=localhost;dbname=test';
$conn  = Connection::getInstance($dsn, 'root', '');
$query = $conn->getPdo()->query('SELECT * FROM `todo`');

foreach ($query as $todo) {
    echo $todo['text'] . '<br>';
}

echo '<br>';
<?php
/**
 * $math  = new Math();
 * $math2 = new Math();
 * $math3 = new Math();
 */
class Math
{ 
    private static $instance = null;
    private $name;

    private function __construct() {}
    private function __clone() {}

    public function test()
    {
        $this->name = 'toto';
    }

    static public function getInstance()
    {
        if (null === self::$instance) {
            echo 'La premiere fois<br>';
            self::$instance = new Math();
        }
        echo 'tout le temps<br>';
        return self::$instance;
    }
}

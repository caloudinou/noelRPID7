<?php

class Connection
{
    private static $instance = null;
    private $pdo = null;

    public function getPdo()
    {
        return $this->pdo;
    }

    public static function getInstance($dsn = '', $username = '', $password = '', array $opts = array())
    {
        if (null === self::$instance) {
            self::$instance = new self($dsn, $username, $password, $opts);
        }
        return self::$instance;
    }

    private function __construct($dsn, $username, $password, $opts)
    {
        $this->pdo = new \PDO($dsn, $username, $password, $opts);
    }

    private function __clone() {}
}

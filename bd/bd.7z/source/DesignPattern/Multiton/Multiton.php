<?php

class Multiton
{
    const PARAM_DSN      = 'dsn';
    const PARAM_USERNAME = 'username';
    const PARAM_PASSWORD = 'password';
    const PARAM_OPTIONS  = 'options';

    static private $instances = array();
    private $pdo = null;

    private $defaultConf = array(
        self::PARAM_DSN      => '',
        self::PARAM_USERNAME => '',
        self::PARAM_PASSWORD => '',
        self::PARAM_OPTIONS  => array(),
    );

    static public function getInstance(array $conf = array())
    {
        $key = serialize($conf);

        if (!isset(self::$instances[$key])) {
            self::$instances[$key] = new Multiton($conf);
        }
        return self::$instances;
    }

    public function getPdo()
    {
        return $this->pdo;
    }

    private function __construct(array $conf)
    {
        $conf = array_merge($this->defaultConf, $conf);

        $this->pdo = new \PDO(
            $conf[self::PARAM_DSN],
            $conf[self::PARAM_USERNAME],
            $conf[self::PARAM_PASSWORD],
            $conf[self::PARAM_OPTIONS]
        );
    }
}

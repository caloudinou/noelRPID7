<?php

require_once 'Multiton.php';
$conf = array(
    Multiton::PARAM_DSN      => 'mysql:host=localhost;dbname=test',
    Multiton::PARAM_USERNAME => 'root',
    Multiton::PARAM_PASSWORD => '',
);

$m = Multiton::getInstance($conf);

$a = array('test' => 'toto');
$b = array('foo'  => 'bar', 'test' => 'MERGE');

echo '<pre>';
print_r(array_merge($a, $b));

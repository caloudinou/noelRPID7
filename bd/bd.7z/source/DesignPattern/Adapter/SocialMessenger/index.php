<?php // SocialMessenger/index.php

require 'Writer.php';
require 'Writer/Mail.php';
require 'Writer/Sms.php';
require 'Api/Facebook.php';
require 'Writer/Adapter/Facebook.php';
require 'Manager.php';

$m = new SocialMessenger\Manager();
$m->addWriter(new SocialMessenger\Writer\Mail());

$sms = new \SocialMessenger\Writer\Sms(array(
    '0623456789',
    '0697563125',
    '0763189422',
));
$m->addWriter($sms);

$fb = new Facebook();
$fbAdapter = new SocialMessenger\Writer\Adapter\Facebook($fb);
$m->addWriter($fbAdapter);

$m->sendMessage("Hello World !!! What'up ?");

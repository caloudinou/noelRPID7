<?php

class Facebook
{
    public function post($msg)
    {
        echo 'Facebook: ' . $msg;
    }
}

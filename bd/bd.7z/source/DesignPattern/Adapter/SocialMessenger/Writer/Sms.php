<?php

namespace SocialMessenger\Writer;

use SocialMessenger\Writer;

class Sms implements Writer
{
    private $numbers = array();

    public function __construct(array $numbers)
    {
        $this->numbers = $numbers;
    }

    public function write($message)
    {
        foreach ($this->numbers as $number) {
            echo 'Sms to ('.$number.'): ' . $message . '<br>';
        }
    }
}

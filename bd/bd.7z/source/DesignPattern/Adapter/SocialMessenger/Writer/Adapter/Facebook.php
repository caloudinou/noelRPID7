<?php 

namespace SocialMessenger\Writer\Adapter;

use SocialMessenger\Writer;

class Facebook implements Writer
{
    private $facebook;

    public function __construct(\Facebook $facebook)
    {
        $this->facebook = $facebook;
    }

    public function write($message)
    {
        $this->facebook->post($message);
    }
}

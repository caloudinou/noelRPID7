<?php 

namespace SocialMessenger\Writer;

use SocialMessenger\Writer;

class Mail implements Writer
{
    public function write($message)
    {
        // $mailer = new Mailer();
        echo 'Mail: ' . $message . '<br>';
    }
}

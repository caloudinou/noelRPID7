<?php

namespace SocialMessenger;

class Manager
{
    private $writers = array();

    public function addWriter(Writer $writer)
    {
        $this->writers[] = $writer;
        return $this;
    }

    public function sendMessage($message)
    {
        echo 'Envoie des messages en cours...<br><br>';

        foreach ($this->writers as $writer) {
            $writer->write($message);
        }
    }
}

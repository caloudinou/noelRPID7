<?php

namespace SocialMessenger;

interface Writer
{
    public function write($message);
}

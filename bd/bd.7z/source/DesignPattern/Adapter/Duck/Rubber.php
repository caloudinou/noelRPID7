<?php

namespace Duck;

class Rubber implements Quackable
{
    public function quack()
    {
        echo 'Rubber: squeak<br>';
    }
}

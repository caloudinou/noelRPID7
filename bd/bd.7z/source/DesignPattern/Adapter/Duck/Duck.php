<?php

namespace Duck;

class Duck implements Quackable
{
    public function quack()
    {
        echo 'Duck: quack quack<br>';
    }
}

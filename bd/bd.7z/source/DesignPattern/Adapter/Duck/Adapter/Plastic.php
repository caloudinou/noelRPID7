<?php

namespace Duck\Adapter;

use Duck\Quackable;

class Plastic implements Quackable
{
    private $plastic;

    public function __construct(\Duck\Plastic $plastic)
    {
        $this->plastic = $plastic;
    }

    public function quack()
    {
        $this->plastic->speak();
    }
}

<?php

namespace Duck\Adapter;

use Duck\Quackable;

class Goose implements Quackable
{
    private $goose;

    public function __construct(\Duck\Goose $goose)
    {
        $this->goose = $goose;
    }

    public function quack()
    {
        $this->goose->honk();
    }
}


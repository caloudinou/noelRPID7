<?php

namespace Duck;

class Plastic
{
    public function speak()
    {
        echo 'Plastic: no speak<br>';
    }
}

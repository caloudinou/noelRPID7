<?php

namespace Duck;

class Goose
{
    public function honk()
    {
        echo 'Goose: Honk<br>';
    }
}

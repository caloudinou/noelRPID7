<?php

namespace Duck;

interface Quackable
{
    public function quack();
}

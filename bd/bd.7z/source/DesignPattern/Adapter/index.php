<?php // Adapter

require_once 'Duck/Goose.php';
require_once 'Duck/Plastic.php';
require_once 'Duck/Quackable.php';
require_once 'Duck/Duck.php';
require_once 'Duck/Rubber.php';
require_once 'Duck/Adapter/Goose.php';
require_once 'Duck/Adapter/Plastic.php';

$goose   = new Duck\Goose();
$plastic = new Duck\Plastic();
$rubber  = new Duck\Rubber();
$duck    = new Duck\Duck();

$plasticAdapter = new \Duck\Adapter\Plastic($plastic);
$gooseAdapter   = new \Duck\Adapter\Goose($goose);

$ducks = [$gooseAdapter, $plasticAdapter, $rubber, $duck];

foreach ($ducks as $d) {
    $d->quack();
}


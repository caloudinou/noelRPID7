<?php
require_once 'MyException.php';

class Test {
    public function __construct($key = null) {
        if ($key === null) {
            throw new Exception('Une simple Exception');
        } elseif ($key === 'toto') {
            throw new MyException('Ma Super Exception');
        }
    }
}

try {
    $test = new Test();
} catch (MyException $e) {
    echo 'test';
    echo $e->getMessage();
} catch (Exception $e) {
     echo 'ok';
     echo $e->getMessage();
}
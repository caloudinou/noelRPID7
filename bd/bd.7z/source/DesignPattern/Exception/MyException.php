<?php

class MyException extends Exception
{
    
}

<?php

namespace Decorator\Without;

class TextStrong extends Text
{
    public function display()
    {
        return '<strong>'.parent::display().'</strong>';
    }
}

<?php

namespace Decorator\Without;

class TextDivItalic extends TextItalic
{
    public function display()
    {
        return '<div>'.parent::display().'<div>';
    }
}
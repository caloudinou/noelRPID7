<?php

namespace Decorator\Without;

class TextDiv extends Text
{
    public function display()
    {
        return '<div>'.parent::display().'</div>';
    }
}

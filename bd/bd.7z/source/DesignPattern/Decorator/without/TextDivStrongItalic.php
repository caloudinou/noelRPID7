<?php

namespace Decorator\Without;

class TextDivStrongItalic extends TextItalic
{
    public function display()
    {
        return '<div><strong>'.parent::display().'</strong></div>';
    }
}

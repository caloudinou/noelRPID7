<?php

namespace Decorator\Without;

class TextDivStrong extends TextStrong
{
    public function display()
    {
        return '<div>'.parent::display().'</div>';
    }
}

<?php

require_once 'Text.php';
require_once 'TextDiv.php';
require_once 'TextStrong.php';
require_once 'TextDivStrong.php';
require_once 'TextItalic.php';
require_once 'TextDivItalic.php';
require_once 'TextDivStrongItalic.php';

use Decorator\Without;

$tdsi = new Without\TextDivStrongItalic('Hi everyone !');
echo $tdsi->display();

<?php

namespace Decorator\Without;

class TextItalic extends Text
{
    public function display()
    {
        return '<em>'.parent::display().'</em>';
    }
}

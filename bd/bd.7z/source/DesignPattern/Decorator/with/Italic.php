<?php

namespace Decorator\With;

class Italic implements Displayer
{
    private $displayer;

    public function __construct(Displayer $displayer)
    {
        $this->displayer = $displayer;
    }

    public function display()
    {
        return '<em>'.$this->displayer->display().'</em>';
    }
}

<?php

namespace Decorator\With;

class Text implements Displayer
{
    private $content;

    public function __construct($content)
    {
        $this->setContent($content);
    }

    public function display()
    {
        return $this->content;
    }

    public function setContent($content)
    {
        $this->content = (string) $content;
        return $this;
    }
}

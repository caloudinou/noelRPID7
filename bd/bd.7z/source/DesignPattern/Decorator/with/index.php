<?php
require_once 'Displayer.php';
require_once 'Text.php';
require_once 'Italic.php';

use Decorator\With\Text,
    Decorator\With\Italic;

$t = new Text('Hi everyone !');
$i = new Italic($t);

echo $i->display();



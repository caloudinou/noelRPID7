<?php

namespace Decorator\With;

interface Displayer
{
    public function display();
}

<?php

namespace Starbuzz;

class Expresso extends Boisson
{
    protected $description = 'Expresso';

    public function cout()
    {
        return 1.80;
    }
}

<?php

namespace Starbuzz;

abstract class Boisson implements Productable
{
    protected $description = "Boisson inconnue";

    public function getDescription()
    {
        return $this->description;
    }
}

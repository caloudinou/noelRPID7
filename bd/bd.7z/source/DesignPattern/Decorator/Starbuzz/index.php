<?php

require_once 'Coster.php';
require_once 'Ingredient.php';
require_once 'Productable.php';
require_once 'Boisson.php';
require_once 'Expresso.php';
require_once 'Ingredient/Lait.php';

$expresso = new \Starbuzz\Expresso();
$lait = new \Starbuzz\Option\Lait($expresso);

echo $lait->getDescription();
echo $lait->cout() .' euros';
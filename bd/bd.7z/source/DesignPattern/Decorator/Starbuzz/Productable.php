<?php

namespace Starbuzz;

interface Productable extends Ingredient, Coster
{
    
}

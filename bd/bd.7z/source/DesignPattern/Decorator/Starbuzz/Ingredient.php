<?php

namespace Starbuzz;

interface Ingredient
{
   public function getDescription();
}

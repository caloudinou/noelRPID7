<?php

namespace Starbuzz;

class Deca extends Boisson
{
    protected $description = 'Deca';

    public function cout()
    {
        return 1.50;
    }
}

<?php

namespace Starbuzz\Ingredient;

use Starbuzz\Productable;

class Caramel implements Productable
{
    public function cout()
    {
        
    }

    public function getDescription()
    {
        
    }

}

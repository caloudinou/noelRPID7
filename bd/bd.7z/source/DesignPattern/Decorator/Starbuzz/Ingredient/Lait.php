<?php

namespace Starbuzz\Option;

use Starbuzz\Productable;

class Lait implements Productable
{
    private $product;

    public function __construct(Productable $p)
    {
        $this->product = $p;
    }

    public function getDescription()
    {
        return $this->product->getDescription() . ', Lait ';
    }

    public function cout()
    {
        return .20 + $this->product->cout();
    }
}

<?php

namespace Starbuzz;

class Capuccino extends Boisson
{
    protected $description = 'Capuccino';

    public function cout()
    {
        return 1.20;
    }
}

<?php

namespace Starbuzz;

interface Coster
{
    public function cout();
}

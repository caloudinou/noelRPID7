<?php
class Cms
{
    private $content;
    private $pageGenerator = null;

    public function __construct($content)
    {
        $this->content = $content;
    }

    public function setPageGenerator(Exportable $exportFactory)
    {
        $this->pageGenerator = $exportFactory;
    }

    public function getPageGenerator()
    {
        if (null === $this->pageGenerator) {
            $this->pageGenerator = new ExportFactory();
        }
        return $this->pageGenerator;
    }

    public function show($format)
    {
        $rendu = $this->getPageGenerator()->export($format);
        $rendu->setContent($this->content);
        return $rendu->render();
    }
}

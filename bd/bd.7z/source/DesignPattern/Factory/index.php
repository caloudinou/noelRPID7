<?php
require_once 'Page.php';
require_once 'Html.php';
require_once 'Json.php';
require_once 'Xml.php';
require_once 'Csv.php';
require_once 'Exportable.php';
require_once 'ExportFactory.php';
require_once 'Cms.php';

$articles[] = array(
    'title' => 'Les Design Patterns',
    'text'  => 'La Factory, the best of the world',
);
$articles[] = array(
    'title' => 'La POO',
    'text'  => 'La programmation orientée objet',
);

$choix = 'xml';
$cms = new Cms($articles);
echo $cms->show($choix);

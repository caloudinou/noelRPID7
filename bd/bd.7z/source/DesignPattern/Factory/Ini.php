<?php

class Ini extends Page
{
    public function render()
    {
        $output = '';

        foreach ($this->getContent() as $content) {
            $output .= 'title = ' . $content['title'] . PHP_EOL;
            $output .= 'text = ' . $content['text'] . PHP_EOL;
        }
        return $output;
    }
}

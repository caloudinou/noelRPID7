<?php
class Html extends Page
{
    public function render()
    {
        $output = '<html><body>';
        $output .= '<section>';

        foreach ($this->getContent() as $content) {
            $output .= '<div>';
            $output .= '<h1>'.$content['title'].'</h1>';
            $output .= '<p>'.$content['text'].'</p>';
            $output .= '</div>';
        }

        $output .= '</section>';
        $output .= '</body></html>';
        return $output;
    }
}

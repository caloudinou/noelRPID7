<?php

interface Exportable
{
    public function export($format);
}

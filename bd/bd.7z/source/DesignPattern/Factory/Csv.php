<?php

class Csv extends Page
{
    public function render()
    {
        $output = '';

        foreach ($this->getContent() as $content) {
            $output .= $content['title'] . ';' . $content['text']. PHP_EOL;
        }

        return $output;
    }
}

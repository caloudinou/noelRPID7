<?php

class ClientFactory implements Exportable
{
    public function export($format)
    {
        if ($format === 'ini') {
            $rendu = new Ini();
        } else {
            $rendu = new Html();
        }
        return $rendu;
    }
}

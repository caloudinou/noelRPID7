<?php

class Json extends Page
{
    public function render()
    {
        return json_encode($this->getContent());
    }
}

<?php

abstract class Page
{
    private $content = array();

    public function getContent()
    {
        return $this->content;
    }

    public function setContent(array $content)
    {
        $this->content = $content;
        return $this;
    }

    abstract public function render();
}

<?php
class ExportFactory implements Exportable
{
    public function export($format)
    {
        switch ($format) {
            case 'xml':
                header('Content-type: application/xml');
                $rendu = new Xml();
                break;
            case 'json':
                header('Content-type: application/json');
                $rendu = new Json();
                break;
            case 'csv':
                header('Content-type: application/csv');
                $rendu = new Csv();
                break;
            case 'html':
            default: 
                $rendu = new Html();
                break;
        }
        return $rendu;
    }
}

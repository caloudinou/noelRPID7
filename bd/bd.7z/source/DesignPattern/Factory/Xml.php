<?php

class Xml extends Page
{
    public function render()
    {
        $output  = '<?xml version="1.0" encoding="UTF-8"?>' . PHP_EOL;
        $output .= '<articles>' . PHP_EOL;

        foreach ($this->getContent() as $content) {
            $output .= '<article>' . PHP_EOL;
            $output .= '<title>'.$content['title'].'</title>' . PHP_EOL ;
            $output .= '<text>'.$content['text'].'</text>' . PHP_EOL;
            $output .= '</article>' . PHP_EOL;
        }
        $output .= '</articles>' . PHP_EOL;
        return $output;
    }
}

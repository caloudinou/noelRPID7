<?php

namespace Model;

class ServiceGallery
{
   public $name;
   public $gallery = null;

   public function __construct($name)
   {
       $this->name = $name;
   }

   public function getPictures()
   {
       if (null === $this->gallery) {
           $this->gallery = new Gallery();
       }
       return $this->gallery->getPictures();
   }
}
<?php // Lazy Loading

require_once 'Picture.php';
require_once 'Gallery.php';
require_once 'Service.php';

$sg = new Model\ServiceGallery('Ipf');

// ici ma gallerie n'a pas encore été chargée
echo '<pre>';
print_r($sg);

// On fait la demande de chargement des images
echo '<pre>';
print_r($sg->getPictures());

echo '<pre>';
print_r($sg);

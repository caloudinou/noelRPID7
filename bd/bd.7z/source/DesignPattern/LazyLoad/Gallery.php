<?php

namespace Model;

class Gallery
{
    public function getPictures()
    {
        return array(
            new Picture('picture A', '/pictureA.jpg'),
            new Picture('picture B', '/pictureB.jpg'),
            new Picture('picture C', '/pictureC.jpg'),
            new Picture('picture D', '/pictureD.jpg'),
        );
    }

    public function insert() {}
    public function update() {}
    public function delete() {}
}
